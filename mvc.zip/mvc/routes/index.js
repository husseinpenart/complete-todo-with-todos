const express = require('express');

const todoController = require('../controller/todos');

const router = express.Router()

router.get('/' , todoController.getIndex)

module.exports = router